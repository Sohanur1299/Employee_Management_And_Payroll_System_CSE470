import express from 'express';
import mongoose from 'mongoose';
import dotenv from 'dotenv';
import cors from 'cors';
import employeeRoutes from './routes/employeeRoutes';
import kpiRoutes from './routes/kpiRoutes';
import productivityRoutes from './routes/productivityRoutes';
import complaintRoutes from './routes/complaintRoutes';
import applicationRoutes from './routes/applicationRoutes';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

mongoose.connect(process.env.MONGODB_URI as string)
  .then(() => console.log('Connected to MongoDB'))
  .catch((error) => console.error('MongoDB connection error:', error));

app.use('/api/employees', employeeRoutes);
app.use('/api/kpis', kpiRoutes);
app.use('/api/productivity', productivityRoutes);
app.use('/api/complaints', complaintRoutes);
app.use('/api/applications', applicationRoutes);

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});

