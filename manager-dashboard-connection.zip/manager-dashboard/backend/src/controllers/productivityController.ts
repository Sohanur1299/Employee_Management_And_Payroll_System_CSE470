import { Request, Response } from 'express';
import Productivity from '../models/Productivity';

export const getProductivityTrend = async (req: Request, res: Response) => {
  try {
    const productivityTrend = await Productivity.find();
    res.json(productivityTrend);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching productivity trend' });
  }
};

