import { Request, Response } from 'express';
import KPI from '../models/KPI';

export const getKPIs = async (req: Request, res: Response) => {
  try {
    const kpis = await KPI.find();
    res.json(kpis);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching KPIs' });
  }
};

