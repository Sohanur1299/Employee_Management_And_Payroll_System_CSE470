import { Request, Response } from 'express';
import Employee from '../models/Employee';

export const getEmployees = async (req: Request, res: Response) => {
  try {
    const employees = await Employee.find();
    res.json(employees);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching employees' });
  }
};

export const dismissEmployee = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    await Employee.findByIdAndUpdate(id, { status: 'Dismissed' });
    res.json({ message: 'Employee dismissed successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Error dismissing employee' });
  }
};

