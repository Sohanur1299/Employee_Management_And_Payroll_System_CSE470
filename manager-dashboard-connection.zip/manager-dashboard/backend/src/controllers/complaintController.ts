import { Request, Response } from 'express';
import Complaint from '../models/Complaint';

export const getComplaints = async (req: Request, res: Response) => {
  try {
    const complaints = await Complaint.find();
    res.json(complaints);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching complaints' });
  }
};

export const handleComplaint = async (req: Request, res: Response) => {
  try {
    const { id, action } = req.params;
    await Complaint.findByIdAndUpdate(id, { status: action === 'approve' ? 'Approved' : 'Disapproved' });
    res.json({ message: `Complaint ${action}d successfully` });
  } catch (error) {
    res.status(500).json({ message: `Error ${req.params.action}ing complaint` });
  }
};

