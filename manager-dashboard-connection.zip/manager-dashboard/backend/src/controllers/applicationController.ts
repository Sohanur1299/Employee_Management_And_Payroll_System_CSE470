import { Request, Response } from 'express';
import Application from '../models/Application';

export const getApplications = async (req: Request, res: Response) => {
  try {
    const applications = await Application.find();
    res.json(applications);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching applications' });
  }
};

export const handleApplication = async (req: Request, res: Response) => {
  try {
    const { id, action } = req.params;
    await Application.findByIdAndUpdate(id, { status: action === 'approve' ? 'Approved' : 'Disapproved' });
    res.json({ message: `Application ${action}d successfully` });
  } catch (error) {
    res.status(500).json({ message: `Error ${req.params.action}ing application` });
  }
};

