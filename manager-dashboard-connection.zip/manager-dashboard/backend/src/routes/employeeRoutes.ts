import express from 'express';
import { getEmployees, dismissEmployee } from '../controllers/employeeController';

const router = express.Router();

router.get('/', getEmployees);
router.post('/:id/dismiss', dismissEmployee);

export default router;

