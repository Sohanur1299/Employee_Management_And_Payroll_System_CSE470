import express from 'express';
import { getProductivityTrend } from '../controllers/productivityController';

const router = express.Router();

router.get('/', getProductivityTrend);

export default router;

