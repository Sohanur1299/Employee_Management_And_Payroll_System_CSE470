import express from 'express';
import { getApplications, handleApplication } from '../controllers/applicationController';

const router = express.Router();

router.get('/', getApplications);
router.post('/:id/:action', handleApplication);

export default router;

