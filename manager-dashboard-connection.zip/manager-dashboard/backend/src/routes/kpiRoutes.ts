import express from 'express';
import { getKPIs } from '../controllers/kpiController';

const router = express.Router();

router.get('/', getKPIs);

export default router;

