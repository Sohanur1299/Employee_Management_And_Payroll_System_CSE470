import express from 'express';
import { getComplaints, handleComplaint } from '../controllers/complaintController';

const router = express.Router();

router.get('/', getComplaints);
router.post('/:id/:action', handleComplaint);

export default router;

