import mongoose from 'mongoose';

const employeeSchema = new mongoose.Schema({
  name: String,
  performance: Number,
  attendance: Number,
  status: { type: String, default: 'Active' },
});

export default mongoose.model('Employee', employeeSchema);

