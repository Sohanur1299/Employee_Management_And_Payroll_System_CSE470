import mongoose from 'mongoose';

const kpiSchema = new mongoose.Schema({
  name: String,
  target: Number,
  achieved: Number,
});

export default mongoose.model('KPI', kpiSchema);

