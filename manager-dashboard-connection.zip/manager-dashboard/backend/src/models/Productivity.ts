import mongoose from 'mongoose';

const productivitySchema = new mongoose.Schema({
  month: String,
  productivity: Number,
});

export default mongoose.model('Productivity', productivitySchema);

