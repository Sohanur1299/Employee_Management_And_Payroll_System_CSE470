import mongoose from 'mongoose';

const applicationSchema = new mongoose.Schema({
  employeeId: mongoose.Schema.Types.ObjectId,
  type: String,
  status: { type: String, default: 'Pending' },
});

export default mongoose.model('Application', applicationSchema);

