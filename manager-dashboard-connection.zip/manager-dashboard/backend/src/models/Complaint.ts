import mongoose from 'mongoose';

const complaintSchema = new mongoose.Schema({
  employeeId: mongoose.Schema.Types.ObjectId,
  description: String,
  status: { type: String, default: 'Pending' },
});

export default mongoose.model('Complaint', complaintSchema);

