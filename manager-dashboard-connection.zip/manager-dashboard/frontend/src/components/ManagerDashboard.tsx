import { useState, useEffect } from "react"
import { Bar, BarChart, Pie, PieChart, Cell, ResponsiveContainer, XAxis, YAxis, Tooltip, Legend } from "recharts"
import { Button } from "./ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table"

interface Employee {
  id: number;
  name: string;
  performance: number;
  attendance: number;
}

interface KPI {
  id: number;
  name: string;
  target: number;
  achieved: number;
}

interface ProductivityTrend {
  month: string;
  productivity: number;
}

interface Complaint {
  id: number;
  employeeId: number;
  description: string;
}

interface Application {
  id: number;
  employeeId: number;
  type: string;
  status: string;
}

export default function ManagerDashboard() {
  const [employees, setEmployees] = useState<Employee[]>([])
  const [kpis, setKpis] = useState<KPI[]>([])
  const [productivityTrend, setProductivityTrend] = useState<ProductivityTrend[]>([])
  const [complaints, setComplaints] = useState<Complaint[]>([])
  const [applications, setApplications] = useState<Application[]>([])
  const [dismissals, setDismissals] = useState<number[]>([])

  useEffect(() => {
    // Fetch data from backend
    const fetchData = async () => {
      try {
        const [employeesRes, kpisRes, productivityRes, complaintsRes, applicationsRes] = await Promise.all([
          fetch('http://localhost:5000/api/employees'),
          fetch('http://localhost:5000/api/kpis'),
          fetch('http://localhost:5000/api/productivity'),
          fetch('http://localhost:5000/api/complaints'),
          fetch('http://localhost:5000/api/applications')
        ])

        const [employeesData, kpisData, productivityData, complaintsData, applicationsData] = await Promise.all([
          employeesRes.json(),
          kpisRes.json(),
          productivityRes.json(),
          complaintsRes.json(),
          applicationsRes.json()
        ])

        setEmployees(employeesData)
        setKpis(kpisData)
        setProductivityTrend(productivityData)
        setComplaints(complaintsData)
        setApplications(applicationsData)
      } catch (error) {
        console.error("Error fetching data:", error)
      }
    }

    fetchData()
  }, [])

  const handleDismissal = async (employeeId: number) => {
    try {
      await fetch(`http://localhost:5000/api/employees/${employeeId}/dismiss`, { method: 'POST' })
      setDismissals([...dismissals, employeeId])
    } catch (error) {
      console.error("Error dismissing employee:", error)
    }
  }

  const handleComplaint = async (complaintId: number, action: "approve" | "disapprove") => {
    try {
      await fetch(`http://localhost:5000/api/complaints/${complaintId}/${action}`, { method: 'POST' })
      // Refresh complaints after action
      const res = await fetch('http://localhost:5000/api/complaints')
      const updatedComplaints = await res.json()
      setComplaints(updatedComplaints)
    } catch (error) {
      console.error(`Error ${action}ing complaint:`, error)
    }
  }

  const handleApplication = async (applicationId: number, action: "approve" | "disapprove") => {
    try {
      await fetch(`http://localhost:5000/api/applications/${applicationId}/${action}`, { method: 'POST' })
      // Refresh applications after action
      const res = await fetch('http://localhost:5000/api/applications')
      const updatedApplications = await res.json()
      setApplications(updatedApplications)
    } catch (error) {
      console.error(`Error ${action}ing application:`, error)
    }
  }

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042']

  return (
    <div className="p-8 space-y-8">
      <Card>
        <CardHeader>
          <CardTitle>Employee Performance and Attendance</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Performance</TableHead>
                <TableHead>Attendance</TableHead>
                <TableHead>Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {employees.map((employee) => (
                <TableRow key={employee.id}>
                  <TableCell>{employee.name}</TableCell>
                  <TableCell>{employee.performance}%</TableCell>
                  <TableCell>{employee.attendance}%</TableCell>
                  <TableCell>
                    <Button
                      variant="destructive"
                      onClick={() => handleDismissal(employee.id)}
                      disabled={dismissals.includes(employee.id)}
                    >
                      {dismissals.includes(employee.id) ? "Dismissal Pending" : "Dismiss"}
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>KPI Performance</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={kpis}>
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="target" fill="#8884d8" name="Target" />
              <Bar dataKey="achieved" fill="#82ca9d" name="Achieved" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Team Productivity Trend</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={productivityTrend}>
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="productivity" fill="#8884d8" name="Productivity" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Performance Distribution</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={employees}
                dataKey="performance"
                nameKey="name"
                cx="50%"
                cy="50%"
                outerRadius={100}
                label
              >
                {employees.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Complaints</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Employee</TableHead>
                <TableHead>Description</TableHead>
                <TableHead>Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {complaints.map((complaint) => (
                <TableRow key={complaint.id}>
                  <TableCell>{employees.find(e => e.id === complaint.employeeId)?.name}</TableCell>
                  <TableCell>{complaint.description}</TableCell>
                  <TableCell>
                    <Button onClick={() => handleComplaint(complaint.id, "approve")} className="mr-2">Approve</Button>
                    <Button variant="destructive" onClick={() => handleComplaint(complaint.id, "disapprove")}>Disapprove</Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>HR-Approved Applications</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Employee</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {applications.map((application) => (
                <TableRow key={application.id}>
                  <TableCell>{employees.find(e => e.id === application.employeeId)?.name}</TableCell>
                  <TableCell>{application.type}</TableCell>
                  <TableCell>{application.status}</TableCell>
                  <TableCell>
                    <Button onClick={() => handleApplication(application.id, "approve")} className="mr-2">Approve</Button>
                    <Button variant="destructive" onClick={() => handleApplication(application.id, "disapprove")}>Disapprove</Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}

