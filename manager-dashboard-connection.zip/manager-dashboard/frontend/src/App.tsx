import ManagerDashboard from './components/ManagerDashboard'

function App() {
  return (
    <div className="App">
      <ManagerDashboard />
    </div>
  )
}

export default App

