"use client"
import React from 'react';
import { useState } from "react";
import { Bar, BarChart, Pie, PieChart, Cell, ResponsiveContainer, XAxis, YAxis, Tooltip, Legend } from "recharts";
import { Button } from "../components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../components/ui/table";
import { employees, kpis, productivityTrend, complaints, applications } from "../mockData";

export default function ManagerDashboard() {
  const [dismissals, setDismissals] = useState<number[]>([])

  const handleDismissal = (employeeId: number) => {
    setDismissals([...dismissals, employeeId])
  }

  const handleComplaint = (complaintId: number, action: "approve" | "disapprove") => {
    // In a real application, you would call an API to update the complaint status
    console.log(`Complaint ${complaintId} ${action}d`)
  }

  const handleApplication = (applicationId: number, action: "approve" | "disapprove") => {
    // In a real application, you would call an API to update the application status
    console.log(`Application ${applicationId} ${action}d`)
  }

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042']

  return (
    <div className="p-8 space-y-8">
      <Card>
<CardHeader>
  <CardDescription>This card displays employee performance and attendance data.</CardDescription>
<CardTitle>Employee Performance and Attendance</CardTitle>
</CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Performance</TableHead>
                <TableHead>Attendance</TableHead>
                <TableHead>Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {employees.map((employee) => (
                <TableRow key={employee.id}>
                  <TableCell>{employee.name}</TableCell>
                  <TableCell>{employee.performance}%</TableCell>
                  <TableCell>{employee.attendance}%</TableCell>
                  <TableCell>
                    <Button
                      variant="destructive"
                      onClick={() => handleDismissal(employee.id)}
                      disabled={dismissals.includes(employee.id)}
                    >
                      {dismissals.includes(employee.id) ? "Dismissal Pending" : "Dismiss"}
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card>
<CardHeader>
  <CardDescription>This card displays KPI performance data.</CardDescription>
<CardTitle>KPI Performance</CardTitle>
</CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={kpis}>
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="target" fill="#8884d8" name="Target" />
              <Bar dataKey="achieved" fill="#82ca9d" name="Achieved" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card>
<CardHeader>
  <CardDescription>This card shows team productivity trends over time.</CardDescription>
<CardTitle>Team Productivity Trend</CardTitle>
</CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={productivityTrend}>
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="productivity" fill="#8884d8" name="Productivity" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card>
<CardHeader>
  <CardDescription>This card illustrates performance distribution among employees.</CardDescription>
<CardTitle>Performance Distribution</CardTitle>
</CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={employees}
                dataKey="performance"
                nameKey="name"
                cx="50%"
                cy="50%"
                outerRadius={100}
                label
              >
                {employees.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card>
<CardHeader>
  <CardDescription>This card lists employee complaints for review.</CardDescription>
<CardTitle>Complaints</CardTitle>
</CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Employee</TableHead>
                <TableHead>Description</TableHead>
                <TableHead>Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {complaints.map((complaint) => (
                <TableRow key={complaint.id}>
                  <TableCell>{employees.find(e => e.id === complaint.employeeId)?.name}</TableCell>
                  <TableCell>{complaint.description}</TableCell>
                  <TableCell>
                    <Button onClick={() => handleComplaint(complaint.id, "approve")} className="mr-2">Approve</Button>
                    <Button variant="destructive" onClick={() => handleComplaint(complaint.id, "disapprove")}>Disapprove</Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Employee</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {applications.map((application) => (
                <TableRow key={application.id}>
                  <TableCell>{employees.find(e => e.id === application.employeeId)?.name}</TableCell>
                  <TableCell>{application.type}</TableCell>
                  <TableCell>{application.status}</TableCell>
                  <TableCell>
                    <Button onClick={() => handleApplication(application.id, "approve")} className="mr-2">Approve</Button>
                    <Button variant="destructive" onClick={() => handleApplication(application.id, "disapprove")}>Disapprove</Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}

