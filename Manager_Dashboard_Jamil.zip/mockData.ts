export const employees = [
    { id: 1, name: "John Doe", performance: 85, attendance: 95 },
    { id: 2, name: "Jane Smith", performance: 92, attendance: 98 },
    { id: 3, name: "Bob Johnson", performance: 78, attendance: 88 },
  ];
  
  export const kpis = [
    { id: 1, name: "Sales Target", target: 100000, achieved: 95000 },
    { id: 2, name: "Customer Satisfaction", target: 95, achieved: 92 },
    { id: 3, name: "Project Completion Rate", target: 100, achieved: 95 },
  ];
  
  export const productivityTrend = [
    { month: "Jan", productivity: 85 },
    { month: "Feb", productivity: 88 },
    { month: "Mar", productivity: 92 },
    { month: "Apr", productivity: 90 },
    { month: "May", productivity: 95 },
  ];
  
  export const complaints = [
    { id: 1, employeeId: 2, description: "Unfair workload distribution" },
    { id: 2, employeeId: 3, description: "Inadequate resources for project" },
  ];
  
  export const applications = [
    { id: 1, employeeId: 1, type: "Promotion", status: "Approved by HR" },
    { id: 2, employeeId: 2, type: "Transfer", status: "Approved by HR" },
  ];