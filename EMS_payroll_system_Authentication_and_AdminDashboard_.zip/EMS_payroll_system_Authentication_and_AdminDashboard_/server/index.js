import express from 'express'
import cors from 'cors'
// import connectDB from './db.js'

const app = express()
// const connectDB = require('./db.js')

app.use(cors())
app.use(express.json())

//connectDB()

app.listen(process.env.PORT, () => {
    console.log(`Server is Running on port ${process.env.PORT}`)
})