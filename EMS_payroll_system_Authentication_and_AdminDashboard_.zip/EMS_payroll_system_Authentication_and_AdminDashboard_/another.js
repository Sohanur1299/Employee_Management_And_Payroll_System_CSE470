
let formatted = true;
if (formatted){
    console.log('My name is SOhanur Rahman Khan')
}
