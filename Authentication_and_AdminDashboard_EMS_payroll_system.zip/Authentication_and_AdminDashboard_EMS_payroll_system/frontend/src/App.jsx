
function App() {

  return (
   <div className="text-3xl text-teal-500"> Welcome to Employee management system </div>
  )
}

export default App
